//
//  AMapFoundationVersion.h
//  AMapFoundation
//
//  Created by xiaoming han on 15/10/26.
//  Copyright © 2015年 Amap. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifndef AMapFoundationVersion_h
#define AMapFoundationVersion_h

#define AMapFoundationVersionNumber    10606

FOUNDATION_EXTERN NSString * const AMapFoundationVersion;
FOUNDATION_EXTERN NSString * const AMapFoundationName;

#endif /* AMapFoundationVersion_h */
